textTitles = ["This Charming Man", "Girl Afraid", "Reel Around The Fountain", "I Want The One I Can't Have", "What She Said"];


text0 = `
Punctured bicycle
on a hillside desolate
will Nature make a man of me yet?

When in this charming car
this charming man

Why pamper life's complexities
when the leather runs smooth on the passenger seat?

I would go out tonight
but I have not got a stitch to wear
this man said "It is gruesome
that someone so handsome should care"

A jumped-up pantry boy
who never knew his place
he said "return the rings"
he knows so much about these things
he knows so much about these things

I would go out tonight
but I have not got a stitch to wear
this man said "It is gruesome
that someone so handsome should care"

This charming man
this charming man

A jumped-up pantry boy
who never knew his place
he said "return the ring"
he knows so much about these things
he knows so much about these things
he knows so much about these things
`;

text1 = `
Girl afraid
where does his intentions lay?
Or does he even have any?

She says:
"He never really looks at me
I give him every opportunity
in the room downstairs
he sat and stared
in the room downstairs
he sat and stared
I will never make that mistake again!"

Boy afraid
prudence never pays
and everything she wants costs money

"But she does not even LIKE me!
and I know because she said so
in the room downstairs
she sat and stared
in the room downstairs
she sat and stared
I will never make that mistake again!"
`;

text2 = `
It is time the tale were told
of how you took a child
and you made him old

It is time the tale were told
of how you took a child
and you made him old
you made him old

Reel around the fountain
slap me on the patio
I will take it now

Fifteen minutes with you
well, I would not say no
oh people said
that you were virtually dead
and they were so wrong!

Fifteen minutes with you
I would not say no
oh people said
that you were easily led
and they were half-right

It is time the tale were told
of how you took a child
and you made him old

It is time the tale were told
of how you took a child
and you made him old
you made him old

Reel around the fountain
slap me on the patio
I will take it now

Fifteen minutes with you
I would not say no
oh people see no worth in you
oh but I do

Fifteen minutes with you
oh I would not say no
oh people see no worth in you
but I do

I dreamt about you last night
and I fell out of bed twice
you can pin and mount me
like a butterfly

But take me to the haven of your bed
was something that you never said
two lumps, please
you are the bee's knees
but so am I

Meet me at the fountain
shove me on the patio
I will take it slowly

Fifteen minutes with you
oh I would not say no
people see no worth in you
oh but I do
`;

text3 = `
On the day that your mentality
Catches up with your biology

I want the one I can not have
And it is driving me mad
It is written all over my face

I want the one I can not have
And it is driving me mad
It is written all over my face

A double-bed
And a stalwart lover, for sure
These are the riches of the poor

A double-bed
And a stalwart lover, for sure
These are the riches of the poor


A tough kid who sometimes swallows nails
Raised on Prisoner's Aid
He killed a policeman when he was thirteen
And somehow that really impressed me
It is written all over my face

On the day that your mentality
Catches up with your biology

And if you ever need self-validation
Just meet me in the alley by the railway-station
It is written all over my face
`;
text4 = `
What she said:
"How come someone has not noticed
that I am dead
and decided to bury me
God knows, I am ready"
What she said was sad
but then, all the rejections she has had
to pretend to be happy
could only be idiocy
What she said was not for the job or
lover that she never had
What she read
all heady books
she would sit and prophesise
(it took a tattooed boy from
Birkenhead
to really really open her eyes)
What she said:
"I smoke 'cos I am hoping for an
early death
AND I NEED TO CLING TO SOMETHING !"
What she said:
"I smoke 'cos I am hoping for an
early death
AND I NEED TO CLING TO SOMETHING !"
`;
